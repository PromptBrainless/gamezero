# Skeleton2D Demo

This demo shows how to create a rigged and animated character in 2D using
Godot's Skeleton2D node. There are several movement-related animations and
there is a simple character controller that controls the animations.

Language: GDScript

Renderer: Compatibility

Check out this demo on the Asset Store: https://store.godotengine.org/asset/godot-foundation/skeleton2d-demo/

## Licenses

GBot character Copyright &copy; circa 2020 Andreas Esau, MIT License.

Initial rigging and animating Copyright &copy; 2020 RustyStriker, MIT License.

## Screenshots

![Screenshot](screenshots/screenshot.png)
